## File: `pdf2tif_lzw_chooseFolder.py`
# pdf2tif_lzw_chooseFolder.py
from qgis.utils import iface
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from pathlib import Path
import subprocess


def popup(title, text, level="info"):
    if level == "warning":
        QMessageBox.warning(None, title, text)
    elif level == "error":
        QMessageBox.critical(None, title, text)
    else:
        QMessageBox.information(None, title, text)


def run_pdf_to_tif():
    """Open a PDF file dialog and convert the selected PDF to a LZW-compressed TIFF.
    Returns True on success, False on cancel or failure."""
    pdf_path, _ = QFileDialog.getOpenFileName(
        None, "Select PDF to Convert", "", "PDF Files (*.pdf *.PDF)"
    )
    if not pdf_path:
        popup("PDF → TIFF", "❌ No PDF selected.", "warning")
        return False

    pdf_path = Path(pdf_path)
    tif_path = pdf_path.with_suffix(".tif")

    popup("PDF → TIFF", f"Converting:\n{pdf_path.name}\n\nPlease wait...", "info")

    try:
        subprocess.run([
            "gdal_translate", "-of", "GTiff", "-co", "COMPRESS=LZW",
            str(pdf_path), str(tif_path)
        ], check=True)
        popup("PDF → TIFF", f"✅ TIFF created successfully!\n\nSaved at:\n{tif_path}", "info")
        return True

    except FileNotFoundError:
        popup("PDF → TIFF", "❌ 'gdal_translate' not found. Ensure GDAL is installed.", "error")
        return False
    except subprocess.CalledProcessError as e:
        popup("PDF → TIFF", f"❌ Conversion failed:\n{e}", "error")
        return False


if __name__ == "__main__":
    run_pdf_to_tif()