import os
import xml.etree.ElementTree as ET

# Path to your plugin folder
plugin_dir = r"C:\Users\mfrno\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\Georref_Workflow_DCC"
plugin_name = "Georref_Workflow_DCC"
plugin_zip = "Georref_Workflow_DCC.zip"
download_url = f"https://yourserver.com/plugins/{plugin_zip}"

# XML structure
plugins = ET.Element("plugins")
plugin = ET.SubElement(plugins, "pyqgis_plugin", {
    "name": plugin_name,
    "version": "1.0.0",
    "qgis_minimum_version": "3.40",
    "qgis_maximum_version": "3.99"
})

ET.SubElement(plugin, "description").text = "Georeferencing workflow automation for QGIS 3.40 Bratislava."
ET.SubElement(plugin, "author_name").text = "mfrno"
ET.SubElement(plugin, "download_url").text = download_url

# Write to plugins.xml
tree = ET.ElementTree(plugins)
xml_path = os.path.join(plugin_dir, "plugins.xml")
tree.write(xml_path, encoding="utf-8", xml_declaration=True)

print(f"✅ Repository file created: {xml_path}")
