# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import QAction, QMenu, QFileDialog, QMessageBox
from PyQt5.QtCore import QSettings
from qgis.PyQt.QtGui import QIcon
from pathlib import Path
import importlib.util
import os

class Georref_Workflow_DCC:
    def __init__(self, iface):
        """Constructor - receives QGIS interface."""
        self.iface = iface
        self.toolbar = None
        self.menu = None
        self.icon_path = os.path.join(os.path.dirname(__file__), "icon_georrefWkfwDCC.png")
        self.icon = QIcon(self.icon_path) if Path(self.icon_path).exists() else QIcon()
        self.settings = QSettings()
        self.default_scripts_dir = Path(__file__).parent / "scripts"
        self.actions = []

    # ----------------------
    # Popup helper
    # ----------------------
    def popup(self, title, text, level="info", confirm=False):
        parent = self.iface.mainWindow()
        if confirm:
            reply = QMessageBox.question(
                parent, title, text, QMessageBox.Yes | QMessageBox.Cancel, QMessageBox.Yes
            )
            return reply == QMessageBox.Yes

        icons = {
            "info": QMessageBox.Information,
            "warning": QMessageBox.Warning,
            "error": QMessageBox.Critical
        }

        msg = QMessageBox(parent)
        msg.setIcon(icons.get(level, QMessageBox.Information))
        msg.setWindowTitle(title)
        msg.setText(text)
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()
        return True

    # ----------------------
    # Script folder management
    # ----------------------
    def get_scripts_folder(self):
        saved_path = self.settings.value("Georref_Workflow_DCC/scripts_folder", "", type=str)
        folder = Path(saved_path) if saved_path else self.default_scripts_dir

        if not folder.exists():
            self.popup("Scripts Folder", "Selecione a pasta onde estão os scripts (.py)", "info")
            new_dir = QFileDialog.getExistingDirectory(self.iface.mainWindow(), "Escolher pasta de scripts")
            if not new_dir:
                self.popup("Scripts Folder", "Operação cancelada. Nenhuma pasta definida.", "warning")
                return None
            folder = Path(new_dir)
            self.settings.setValue("Georref_Workflow_DCC/scripts_folder", str(folder))

        return folder

    def change_scripts_folder(self):
        new_dir = QFileDialog.getExistingDirectory(self.iface.mainWindow(), "Escolher nova pasta de scripts")
        if not new_dir:
            self.popup("Scripts Folder", "Operação cancelada.", "info")
            return
        self.settings.setValue("Georref_Workflow_DCC/scripts_folder", new_dir)
        self.popup("Scripts Folder", f"✅ Nova pasta definida:\n{new_dir}", "info")

    # ----------------------
    # Run scripts safely
    # ----------------------
    def run_script(self, script_name):
        folder = self.get_scripts_folder()
        if not folder:
            return False
        script_path = folder / script_name

        if not script_path.exists():
            self.popup("Execução de Script", f"❌ Script não encontrado:\n{script_path}", "error")
            return False

        try:
            spec = importlib.util.spec_from_file_location(script_name, str(script_path))
            mod = importlib.util.module_from_spec(spec)
            mod.iface = self.iface
            spec.loader.exec_module(mod)

            for fn in ("run_pdf_to_tif", "run_polygon_grid", "run_export_vertices_csv"):
                if hasattr(mod, fn):
                    result = getattr(mod, fn)()
                    return bool(result)

            self.popup("Script", f"❌ No run_*() function found in {script_name}", "error")
            return False

        except Exception as e:
            self.popup("Execução de Script", f"❌ Erro:\n{e}", "error")
            return False

    # ----------------------
    # Plugin steps
    # ----------------------
    def step_pdf_to_tif(self):
        if not self.popup("PDF → TIFF", "Deseja iniciar a conversão de PDF para TIFF?", confirm=True):
            return
        self.popup("PDF → TIFF", "Iniciando conversão...", "info")
        ok = self.run_script("pdf2tif_lzw_chooseFolder.py")
        if ok:
            self.popup("PDF → TIFF", "✅ Conversão concluída com sucesso!", "info")

    def step_create_grid(self):
        if not self.popup("Grid Creation", "Deseja criar grelha de pontos?", confirm=True):
            return
        self.popup("Grid Creation", "Iniciando grelha...", "info")
        ok = self.run_script("molduraEgrelhaFresh.py")
        if ok:
            self.popup("Grid Creation", "✅ Grelha criada com sucesso!", "info")

    def step_georef_tif(self):
        if not self.popup("Georeferencer", "Abrir Georeferencer?", confirm=True):
            return
        found = False
        for act in self.iface.mainWindow().findChildren(QAction):
            if act.text().startswith(("Georeferencer", "Georreferenciador")):
                act.trigger()
                self.popup("Georeferencer", "✅ Georeferencer carregado. Selecionar TIF...", "info")
                found = True
                break
        if not found:
            self.popup("Georeferencer", "❌ Plugin Georeferencer não encontrado.", "error")

    def step_export_vertices_csv(self):
        if not self.popup("Export CSV", "Deseja exportar vértices da camada ativa para CSV?", confirm=True):
            return
        self.popup("Export CSV", "Iniciando exportação...", "info")
        ok = self.run_script("shp2csvInALinePerPolig.py")
        if ok:
            self.popup("Export CSV", "✅ Exportação concluída com sucesso!", "info")

    # ----------------------
    # QGIS plugin GUI
    # ----------------------
    def initGui(self):
        self.menu = QMenu("Georref Workflow - DCC", self.iface.mainWindow())

        steps = [
            ("1 - PDF → TIFF", self.step_pdf_to_tif),
            ("2 - Gerar Grelha de pontos", self.step_create_grid),
            ("3 - Abrir Georeferencer", self.step_georef_tif),
            ("4 - Exportar Coord. em CSV", self.step_export_vertices_csv),
        ]
        for name, func in steps:
            act = QAction(name, self.iface.mainWindow())
            act.triggered.connect(func)
            self.menu.addAction(act)
            self.actions.append(act)

        self.menu.addSeparator()

        act_change = QAction("⚙️ Alterar pasta de scripts", self.iface.mainWindow())
        act_change.triggered.connect(self.change_scripts_folder)
        self.menu.addAction(act_change)
        self.actions.append(act_change)

        self.main_action = QAction(self.icon, "Georref Workflow - DCC", self.iface.mainWindow())
        self.main_action.setMenu(self.menu)
        self.toolbar = self.iface.addToolBar("Georref Workflow - DCC")
        self.toolbar.addAction(self.main_action)

    # ----------------------
    # Unload plugin
    # ----------------------
    def unload(self):
        for act in self.actions:
            self.iface.removePluginMenu("Georref Workflow - DCC", act)
            self.iface.removeToolBarIcon(act)
        self.actions.clear()
        if self.toolbar:
            self.toolbar.deleteLater()
            self.toolbar = None
        if self.menu:
            self.menu.deleteLater()
            self.menu = None
        self.main_action = None
