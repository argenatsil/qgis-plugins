## File: `shp2csvInALinePerPolig.py`
# shp2csvInALinePerPolig.py
from pathlib import Path
from qgis.core import QgsWkbTypes
from qgis.utils import iface
from PyQt5.QtWidgets import QMessageBox, QFileDialog


def popup(title, text, level="info"):
    if level == "warning":
        QMessageBox.warning(None, title, text)
    elif level == "error":
        QMessageBox.critical(None, title, text)
    else:
        QMessageBox.information(None, title, text)


def run_export_vertices_csv():
    """Export polygon vertices of the active layer into a CSV file.
    Returns True on success, False on cancel or error."""
    layer = iface.activeLayer()
    if not layer:
        popup("Export CSV", "❌ No active layer selected. Please select a polygon layer.", "error")
        return False

    if layer.geometryType() != QgsWkbTypes.PolygonGeometry:
        popup("Export CSV", "❌ Active layer is not a polygon layer.", "error")
        return False

    default_name = Path(layer.source()).stem + "_vertices.csv"
    csv_file, _ = QFileDialog.getSaveFileName(None, "Save CSV as", default_name, "CSV Files (*.csv *.txt)")
    if not csv_file:
        popup("Export CSV", "Operation cancelled by user.", "warning")
        return False

    popup("Export CSV", f"Starting export of vertices from layer: {layer.name()}", "info")

    try:
        with open(csv_file, "w", encoding="utf-8") as f:
            for feature in layer.getFeatures():
                geom = feature.geometry()
                coords_list = []

                if geom.isMultipart():
                    polygons = geom.asMultiPolygon()
                else:
                    polygons = [geom.asPolygon()]

                for poly in polygons:
                    for ring in poly:  # exterior + interior rings
                        for pt in ring:
                            coords_list.append(f"{pt.x()},{pt.y()}")

                line = ";".join(coords_list)
                f.write(f"{line}\n")

        popup("Export CSV", f"✅ CSV exported successfully!\nSaved at:\n{csv_file}", "info")
        return True

    except Exception as e:
        popup("Export CSV", f"❌ Export failed:\n{e}", "error")
        return False


if __name__ == "__main__":
    run_export_vertices_csv()

