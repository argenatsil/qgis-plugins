# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsVectorFileWriter, QgsFeature,
    QgsGeometry, QgsPointXY, QgsField, QgsFields, QgsCoordinateReferenceSystem,
    QgsWkbTypes, QgsFillSymbol, QgsSingleSymbolRenderer, QgsMarkerSymbol
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import (
    QDialog, QFormLayout, QDialogButtonBox, QLineEdit, QRadioButton, QButtonGroup,
    QLabel, QComboBox, QMessageBox
)
from qgis.utils import iface
import os

# === Paths and CRS ===
project = QgsProject.instance()
project_dir = project.homePath() or os.getcwd()
polygon_path = os.path.join(project_dir, "pol_grid.shp")
grid_path = os.path.join(project_dir, "grid_pol.shp")
crs = QgsCoordinateReferenceSystem("EPSG:3763")

# === Helper functions ===
def remove_layer_by_name(name):
    layers_to_remove = [layer for layer in QgsProject.instance().mapLayers().values() if layer.name() == name]
    for layer in layers_to_remove:
        QgsProject.instance().removeMapLayer(layer.id())

def delete_shapefile(path):
    extensions = [".shp", ".shx", ".dbf", ".prj", ".cpg", ".qpj"]
    base = os.path.splitext(path)[0]
    for ext in extensions:
        file_path = base + ext
        if os.path.exists(file_path):
            os.remove(file_path)

def frange(start, stop, step):
    if step > 0:
        while start <= stop:
            yield start
            start += step
    else:
        while start >= stop:
            yield start
            start += step

# === Dialog for polygon + grid parameters ===
class PolygonGridDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Criar Polígono + Grelha – CRS: EPSG:3763")
        layout = QFormLayout(self)

        # Polygon inputs
        self.x_label = QLabel("Coordenada X: ")
        self.y_label = QLabel("Coordenada Y: ")
        self.x_input = QLineEdit("0.0")
        self.y_input = QLineEdit("0.0")
        layout.addRow(self.x_label, self.x_input)
        layout.addRow(self.y_label, self.y_input)

        self.width_input = QLineEdit("100.0")
        self.height_input = QLineEdit("100.0")
        layout.addRow("Largura:", self.width_input)
        layout.addRow("Altura:", self.height_input)

        # Corner selection
        from qgis.PyQt.QtWidgets import QHBoxLayout
        origem_label = QLabel("<b>Origem:</b>")
        layout.addRow(origem_label)
        self.corner_group = QButtonGroup(self)
        self.corner_radios = {}
        corner_layout = QHBoxLayout()
        corners = ["Inf-Esq", "Inf-Dir", "Sup-Esq", "Sup-Dir"]
        for corner in corners:
            radio = QRadioButton(corner)
            self.corner_group.addButton(radio)
            self.corner_radios[corner] = radio
            corner_layout.addWidget(radio)
            radio.toggled.connect(self.update_labels)
        self.corner_radios["Inf-Esq"].setChecked(True)
        layout.addRow(corner_layout)

        # Grid inputs
        self.spacing_input = QLineEdit("100.0")
        layout.addRow("Espaçamento entre Pontos:", self.spacing_input)

        self.direction_combo = QComboBox()
        self.direction_combo.addItems([
            "Horizontal → then ↑", "Horizontal → then ↓",
            "Horizontal ← then ↑", "Horizontal ← then ↓",
            "Vertical ↑ then →", "Vertical ↑ then ←",
            "Vertical ↓ then →", "Vertical ↓ then ←"
        ])
        layout.addRow("Direção do Preenchimento:", self.direction_combo)

        self.coverage_combo = QComboBox()
        self.coverage_combo.addItems(["Só dentro do Polígono", "Dentro do Polígono (e Limite)"])
        layout.addRow("Cobertura da Grelha:", self.coverage_combo)

        # Digitizing layer name
        self.digitize_name_input = QLineEdit("nome_da_shape")
        layout.addRow("Ficheiro para vetorizar:", self.digitize_name_input)

        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(buttons)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

    def update_labels(self):
        corner = next((c for c, r in self.corner_radios.items() if r.isChecked()), "Inf-Esq")
        self.x_label.setText(f"Coordenada X : {corner} ")
        self.y_label.setText(f"Coordenada Y : {corner} ")

    def getValues(self):
        corner = next(c for c, radio in self.corner_radios.items() if radio.isChecked())
        x = float(self.x_input.text())
        y = float(self.y_input.text())
        width = float(self.width_input.text())
        height = float(self.height_input.text())
        spacing = float(self.spacing_input.text())
        direction = self.direction_combo.currentText()
        coverage = self.coverage_combo.currentText()
        digitize_name = self.digitize_name_input.text().strip()
        return x, y, width, height, spacing, corner, direction, coverage, digitize_name

# === Main function ===
def run_polygon_grid():
    dlg = PolygonGridDialog()
    if dlg.exec_() != QDialog.Accepted:
        QMessageBox.information(None, "Cancelado", "Operação cancelada pelo utilizador.")
        return False

    try:
        x, y, width, height, spacing, corner, direction, coverage, digitize_name = dlg.getValues()
    except ValueError as e:
        QMessageBox.critical(None, "Erro de Entrada", str(e))
        return False

    digitize_path = os.path.join(project_dir, f"{digitize_name}.shp")

    # Remove previous layers/files
    remove_layer_by_name("pol_grid")
    remove_layer_by_name("grid_pol")
    remove_layer_by_name(digitize_name)
    delete_shapefile(polygon_path)
    delete_shapefile(grid_path)
    delete_shapefile(digitize_path)

    # Compute polygon corners
    if corner == "Inf-Esq":
        x_min, y_min = x, y
        x_max, y_max = x + width, y + height
    elif corner == "Inf-Dir":
        x_min, y_min = x - width, y
        x_max, y_max = x, y + height
    elif corner == "Sup-Esq":
        x_min, y_min = x, y - height
        x_max, y_max = x + width, y
    elif corner == "Sup-Dir":
        x_min, y_min = x - width, y - height
        x_max, y_max = x, y

    points = [
        QgsPointXY(x_min, y_min),
        QgsPointXY(x_max, y_min),
        QgsPointXY(x_max, y_max),
        QgsPointXY(x_min, y_max),
        QgsPointXY(x_min, y_min)
    ]

    # Create polygon shapefile
    fields = QgsFields()
    fields.append(QgsField("id", QVariant.Int))
    writer = QgsVectorFileWriter(polygon_path, "UTF-8", fields, QgsWkbTypes.Polygon, crs, "ESRI Shapefile")
    polygon_feat = QgsFeature()
    polygon_feat.setGeometry(QgsGeometry.fromPolygonXY([points]))
    polygon_feat.setAttributes([1])
    writer.addFeature(polygon_feat)
    del writer

    polygon_layer = QgsVectorLayer(polygon_path, "pol_grid", "ogr")
    symbol = QgsFillSymbol.createSimple({'color': 'transparent', 'outline_color': 'red', 'outline_width': '0.8'})
    polygon_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    QgsProject.instance().addMapLayer(polygon_layer)

    polygon_geom = QgsGeometry.unaryUnion([f.geometry() for f in polygon_layer.getFeatures()])

    def point_in_polygon(pt):
        pt_geom = QgsGeometry.fromPointXY(pt)
        if coverage == "Só dentro do Polígono":
            return polygon_geom.contains(pt_geom)
        else:
            return polygon_geom.contains(pt_geom) or polygon_geom.touches(pt_geom)

    y_start, y_end = (y_min, y_max) if corner in ["Inf-Esq", "Inf-Dir"] else (y_max, y_min)
    x_start, x_end = (x_min, x_max) if corner in ["Inf-Esq", "Sup-Esq"] else (x_max, x_min)
    if "Horizontal" in direction:
        x_step = spacing if "→" in direction else -spacing
        y_step = spacing if "↑" in direction else -spacing
        primary_axis = "x"
    else:
        y_step = spacing if "↑" in direction else -spacing
        x_step = spacing if "→" in direction else -spacing
        primary_axis = "y"

    # Create grid shapefile
    grid_fields = QgsFields()
    grid_fields.append(QgsField("id", QVariant.Int))
    grid_writer = QgsVectorFileWriter(grid_path, "UTF-8", grid_fields, QgsWkbTypes.Point, crs, "ESRI Shapefile")
    point_id = 1
    if primary_axis == "x":
        for y_coord in frange(y_start, y_end, y_step):
            for x_coord in frange(x_start, x_end, x_step):
                pt = QgsPointXY(x_coord, y_coord)
                if point_in_polygon(pt):
                    feat = QgsFeature()
                    feat.setGeometry(QgsGeometry.fromPointXY(pt))
                    feat.setAttributes([point_id])
                    grid_writer.addFeature(feat)
                    point_id += 1
    else:
        for x_coord in frange(x_start, x_end, x_step):
            for y_coord in frange(y_start, y_end, y_step):
                pt = QgsPointXY(x_coord, y_coord)
                if point_in_polygon(pt):
                    feat = QgsFeature()
                    feat.setGeometry(QgsGeometry.fromPointXY(pt))
                    feat.setAttributes([point_id])
                    grid_writer.addFeature(feat)
                    point_id += 1
    del grid_writer

    grid_layer = QgsVectorLayer(grid_path, "grid_pol", "ogr")
    symbol = QgsMarkerSymbol.createSimple({"name": "cross", "color": "blue", "size": "4.5"})
    grid_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    QgsProject.instance().addMapLayer(grid_layer)

    # --- Create empty polygon layer for digitizing ---
    digitize_fields = QgsFields()
    digitize_fields.append(QgsField("id", QVariant.Int))
    digitize_writer = QgsVectorFileWriter(digitize_path, "UTF-8", digitize_fields, QgsWkbTypes.Polygon, crs, "ESRI Shapefile")
    del digitize_writer
    digitize_layer = QgsVectorLayer(digitize_path, digitize_name, "ogr")
    symbol = QgsFillSymbol.createSimple({'color': 'transparent', 'outline_color': 'green', 'outline_width': '1.0'})
    digitize_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    QgsProject.instance().addMapLayer(digitize_layer)

    # Zoom to digitizing layer and make it active
    iface.setActiveLayer(digitize_layer)
    #iface.mapCanvas().setExtent(digitize_layer.extent())
    iface.mapCanvas().refresh()

    iface.messageBar().pushSuccess("Sucesso", "✅ Polígono, grelha e camada para digitação criados!")
    QMessageBox.information(None, "Concluído!", f"Polígono: {polygon_path}\nGrelha: {grid_path}\nCamada digitação: {digitize_path}")
    return True

# --- Standalone execution ---
if __name__ == "__main__":
    run_polygon_grid()
